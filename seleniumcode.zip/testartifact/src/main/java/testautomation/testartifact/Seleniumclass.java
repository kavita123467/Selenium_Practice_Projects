package testautomation.testartifact;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Seleniumclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.setProperty("webdriver.chrome.driver", "C:\\sel learning\\Driver\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		 
		WebDriverManager.chromedriver().setup();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	        // Instantiate a ChromeDriver class.
	        //WebDriver driver = new ChromeDriver();
	        
	        driver.get("https://www.google.com");
	        String title=driver.getTitle();
			System.out.println("page title" +title);
			System.out.println("URL :"+driver.getCurrentUrl());
	}

}
