/**
 * 
 */
/**
 * 
 */
module practics {
}