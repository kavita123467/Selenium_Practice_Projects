package practics;

public class Object_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Object obj=new Object();
       // Object obj[]= {1,2,5,6,23.45,67.89,"hello",'m','g'};
        Object obj1[][]=new Object[3][4];
       
        obj1[0][0]="hello";
        obj1[0][1]=23.56;
        obj1[0][2]=16;
        obj1[0][3]=true;
        
        obj1[1][0]="hello1";
        obj1[1][1]=26.56;
        obj1[1][2]=18;
        obj1[1][3]=false;
        
        obj1[2][0]="hello2";
        obj1[2][1]=29.56;
        obj1[2][2]=19;
        obj1[2][3]=true;
        
        System.out.println("length of row the object is : "+obj1.length);
        System.out.println("length of coln the object is : "+obj1[0].length);
        
        //print all value of the object
        System.out.println("******************************** ");
        int row=obj1.length;
        int col=obj1[0].length;
        
        for(int i=0;i<row;i++)
        {
        	for(int k=0;k<col;k++)
        	{
        		System.out.print(obj1[i][k]+" ");
        	}
        	System.out.println(" ");
        }
	}

}
