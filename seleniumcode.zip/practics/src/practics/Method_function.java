package practics;

public class Method_function {
	//object refrense can call method like private,protected,if they are static in nature then also we can call
	private void badroom()
	{
		System.out.println("this is private");
	}
	protected void bad()
	{
		System.out.println("this is protected");
	}
//default method can we created into the interface 
 //default void value1()
 //{
 //}
 //}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("this is main method");
		//method- independent unit of execution.They have logic.They execute this method under certain conditions.
		// access modifier- static(optional),return type, name of the method,body
		//main method ke ander ager method bnayenge to kam nahi krega just because method are independent.
		//parllel rakh sakhte hai
		//access modifier public, private, protected, default
		
		//call non static method using object
		Method_function obj=new Method_function();
		int n=obj.test();
		System.out.println(n);
		String str4=obj.simple();
		System.out.println(str4);
		boolean b3=obj.validation();
		System.out.println(b3);
		//not value retuen so nothing will print
		obj.badroom();
		obj.bad();
	}
	public int test()
	{
		int k=5;
		int l=10;
		int m=k+l;
		return m;
		//void can't return any value so change void into int.public void test()
	}
	public String simple()
	{
		String str="hello";
		String str1="hello1";
		String str2="hello2";
		String str3=str1+str2+str;
		return str3;
		
	
		
	}
	public boolean validation()
	{
		boolean b1=10<20;
		boolean b2=20<30;
		return b2;
	}
	}

