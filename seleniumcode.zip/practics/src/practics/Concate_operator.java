package practics;

public class Concate_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println(a+b);
		String x="hello";
		String y="JAVA";
		System.out.println(x+y);
		System.out.println(a+b+x+y);//30 hello java
		System.out.println(x+y+a+b);//output will be hello java 10 20
		char c1='a';
		char c2='$';
		System.out.println(c1+c2);//133 ascric value
		
		boolean b1=true;
		boolean b2=false;
		//System.out.println(b1+b2);//boolean value can't be concatinate with  anyone
		System.out.println(c1+x+b2); //possible
		//System.out.println(c1+b2);//not possible
		
		double d1=10.23;
		double d2=23.45;
		System.out.println(d1+d2);//33.68 varies after decimal
		
		System.out.println(x+y+(a+b));//after string its will return 30 value
		
		System.out.println(x+y+a+b+b1+c1+c2+d1+d2+b2);
		System.out.println("the value of a is: a"); //string will print
		System.out.println("the value of a is:"+a);//10
		System.out.println("the value of a is:"+a+b);//1020 used a first
		System.out.println("the value of a is:"+(a+b));//30
		
		
		
	}

}
