package practics;

public class Incremented_Decrement_complecated {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m=100;//yahaan pe start m=100,no increment no decrement
		int n=m--;//yahaan pe n=100, m ke latest value ab 99 ho jaye hai.
		System.out.println("the latest value of m is:"+m);//m=99
		int p=--m;//p ke latest value will be 98,m ke latest value 98
		int l=n--;//l ke value yaha pe 100 hogi and n ke value 99 ko jayege
		//int z=--p+--n;//yahaan pe p ke value 97 ko jayegee,or n will be 98
		int z=p--+--n;//yahaan z=98+98=196,p=98,n=99 latest value is 99 it will become 98
		System.out.println("the value of z is :"+ z);
		System.out.println("the value of p is" + p);
		z=--p-++n;//yahaan pe z=96-99=-3
		System.out.println("the value of z is :"+ z);
		
		System.out.println("the value of n is:"+n);//n value 98 latest
		System.out.println("this post increment parameter will print:"+ n++);//print hogi 98 but latest value of n inside logic will be 99
		System.out.println("this pre increment parameter will print:"+ ++n);//100 this will print and n ke value bhi 100 ho jayegi
		System.out.println("this post decrement parameter will print:"+ n--);//print hoga 100 but n ke latest value 99 ho jayegi
		System.out.println("this pre decrement parameter will print:"+ --n);//print kregi 98 aur n ke latest value bhi 98 ho jayegi

		System.out.println("the value of p is" + p);
		
		System.out.println("the value of p is" + l);
		System.out.println("the value of p is" + z);
		
		
		
	}

}
