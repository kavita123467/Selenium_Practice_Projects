package practics;

public class If_ElseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x="Hello";
		String y="Java";
		//if(x==y)//not equal
		if(x!=y)	
		{
		System.out.println("Both the strings are equal");
		}
		else
		{
			System.out.println("Both the string are not equal");	
		}
		String z1="I am very happy";
		String z2="I will be very happy";
		if(z1.equals("I am very happy"))
		{
			System.out.println("Logic inside the loop will print"+ z1);
		}
		else
		{
			System.out.println("this will print if condition false");
		}
		if(z1.equals(z2))
		{
			System.out.println("Both the string are equal");
		}
		else
			System.out.println("Both the string are  not equal");
		}
	}

