package practics;

public class While_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		while(i<=10)//will print 1 to 9 if we use <=10 it will go till 10
			//while(i<10)
		{
			System.out.println(i);
			//if not intailize i++ it will go infinite
			//i++;
			++i;//will print the same no difference in i++ or ++i in while loop
		}
		

	}

}
