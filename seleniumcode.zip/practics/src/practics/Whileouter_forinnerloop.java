package practics;

public class Whileouter_forinnerloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   //homework forloop outside while inner loop
		int i=1;
		while(i<=5)//outerloop
		{
			System.out.println("repitation of i value is "+ i);//i=1
			//i++;//if not terminate infinite loop
			for(int j=1;j<=5;j++)
			{
				System.out.println("i = " + i +" j = " +j ); //if we use i++ upper the for loop value of i will be 2 i=2//j=1
			}
			i++;
		}

	}

}
