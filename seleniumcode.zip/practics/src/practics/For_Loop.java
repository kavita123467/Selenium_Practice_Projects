package practics;

public class For_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++)
		{
			System.out.print("i = "+i);//will execute start from 1 then check i<=10 condition
			//then i++, after that value will be 2 then check less than and print then i++ will execute.
			//backward number			
		}
		System.out.println();
		System.out.println("*************************");
		for(int j=5;j>=1;j--)
		{
		System.out.print("j = "+ j );
		}
		System.out.println();
		System.out.println("*****************************");
		//print sum of 200 natural number natural number start from 1 and whole number start from 0
 int sum=0;
 for(int k=1;k<=200;k++)
 {
	sum=sum+k;
 }
 System.out.println("value of 200 natural numbers is "+ sum);
	}

}
