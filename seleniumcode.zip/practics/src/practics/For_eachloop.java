package practics;

public class For_eachloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//enhanced for loop or mutated for loop
		//when we use collections then we use foreach loop
		//this loop iterate every item of collection
		//code more readable and less complicated
		//syntax is easy
char vowels[]= {'a','e','i','o','u'};
for(char item:vowels) {
	System.out.println(item+" ");
}
int number[]= {10,10,10,10};
int sum=0;
for(int items1:number)
{
	sum=sum+items1;
}
System.out.println(sum+" this is sum of numbers");
	}

}
