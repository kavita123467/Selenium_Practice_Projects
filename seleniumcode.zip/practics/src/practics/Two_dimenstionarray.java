package practics;

public class Two_dimenstionarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i[][]= { {1,2,3},//{1,2,3} three coln
             {3,4,6},
             {5,6,8} //3 coln three rows will also we similar and if coln will decrease in any row coln will be according to the one above array
              };
System.out.println("the number of rows are : " +i.length);
System.out.println("the number of column are : "+ i[0].length);
for(int j=0;j<i.length;j++)
{
	for(int k=0;k<i[j].length;k++)
	{
		//j=0,k=0
		System.out.print(i[j][k] + " ");//inline print
		// output will be the number of rows are : 3
		//the number of column are : 3
		//1 2 3  
		//3 4 6  
		//5 6 8  

	}
	System.out.println(" ");
}
	
	String str[][]=new String[3][4];
	str[0][0]="java";
	str[0][1]="c";
	str[0][2]="use";
    str[0][3]="my";
	
    str[1][0]="java1";
	str[1][1]="c1";
	str[1][2]="use1";
    str[1][3]="my1";
	
    str[2][0]="java2";
	str[2][1]="c2";
	str[2][2]="use2";
    str[2][3]="my2";
    System.out.println("the number of rows are : " +str.length);
    System.out.println("the number of column are : "+ str[0].length);
	int rows=str.length;
	int cols=str[0].length;
	
	for(int rownum=0;rownum<rows;rownum++)
	{
		for(int colnum=0;colnum<cols;colnum++)
		{
			System.out.print(str[rownum][colnum]+" ");
		}
		System.out.println(" ");	
	}
	

	}

}
