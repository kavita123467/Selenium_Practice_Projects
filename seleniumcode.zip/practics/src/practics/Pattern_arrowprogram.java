package practics;

public class Pattern_arrowprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++)
		{
			System.out.println();	
			for(int j=1;j<=i;j++)
			{
				System.out.print("1");
			}
		}
		int downstair=5;
		for(int k=1;k<=downstair;k++)
		{
			System.out.println();
			for(int l=downstair;l>=k;l--)
			{
				System.out.print("1");
		}
		
		}
	}

}
