package practics;

public class Increment_Decrement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=7;//yahaa pe i=7 hai
		int j=i++;//post increment 2 operation hote hai j=i, second operation hai i ke value change hoti hai
		//j yyahapee j ki value 7 hi hogi ,yahaan i badhke 8 ho jayegi.
		//System.out.println(i);//8
		//System.out.println(j);//7
				
int a=5;//yahaan pe a ke value 5 hi hai
int b=++a;//b ke value will become 6 ,a bhi 6 ho jayegi
System.out.println(a);//6
System.out.println(b);//6

int x=10;//yahaan x ke value 10 hi hai
int y=x--;//yahaan pe y 10 hi rahegi, lekin yahaan x ki value 9 ho jayegi
System.out.println(x);//9
System.out.println(y);//10 latest value will be printed


	}

}
