package practics;

public class Nested_Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=1;
while(i<=10)
{
	System.out.println("value of i is"+i);
	i++;
	int j=5;
	while(j>=1)
	{
		System.out.println("i = "+ i +"j = "+ j);
		j--;
	}
	//i++; i value will print till 11
}
	}

}
