package practics;

public class Inc_Dec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;//i=10
        int j=i++;//j=10,i=11
        int k=i++ + j++;//10+11=21 , j=11, i=12
        int l=++k + ++i + ++j;//22+13+12=47//k=22,i=13,j=12
        
        //post decrement
       
        int m=l-- + k-- - j-- - i--;//47+22-12-13=44,l=46,k=21,j=11,i=12
       
        //pre decrement
       int n=--m + --l - --k - --j + --i;//43+ 45-20-10+11=69, m=43,l=45,k=20,j=10,i=11
       int o=n++ + --m - ++l - k-- + --j - i++ ;//0=69+42-46-20+9-11=43
       //n=70,m=42,l=46,k=19,j=9,i=12,0=43
       int p=o++ + --o - n++ + n-- - --l + k++ - ++j - --j + j++ + i++;
        //p=o++(43)o is =44 now, + --o (44-1=43),n=71 now,n--n=70 now l=(--l =46-1=45)
     //k=19 now 19+1=20,j=9+1=10 now j=10-1=9,j=9+1=10 now,i=12+1=13
       //p=43+43-70+71-45+19-10-9+9+12=63
        System.out.println(i);//12
        System.out.println(j);//9
        System.out.println(k);//19
        System.out.println(l);//46
        System.out.println(m);//42
        System.out.println(n);//70
        System.out.println(o);//43
        System.out.println(p);//63
        
	}

}
