package practics;

public class Nested_forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//for loop inside a for loop
		//inner loop will execute for outer value
for(int i=1;i<=5;i++)
{
	//inner for loop will print first System.out.println("value of i is "+i);
	System.out.println("value of i is "+i);
	System.out.println("*******");
	for(int j=1;j<=5;j++)
	{
		System.out.println("i = "+ i +"j = " + j);
	}
	//outer for loop System.out.println("value of i is "+i);
	System.out.println("value of i is "+i);
}
	}

}
