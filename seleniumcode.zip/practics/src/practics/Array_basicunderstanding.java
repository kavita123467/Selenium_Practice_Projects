package practics;

public class Array_basicunderstanding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int i=10,20,30,40;//will not work
		//int[] i= {10,20,30,40,50};//we can also declare this it also work properlly
		int i[]= {10,20,30,40,50};
		//it will take similar data type only//int i[]={10,true,'hello',23.45};will not work;
	String str[]={"hello","world","why"};
	System.out.println("length of array is :"+ str.length);
	System.out.println(str[1]);
	System.out.println(str[2]);
	for(int j=0;j<str.length;j++)
	{
		System.out.println(str[j]+" ");
		//System.out.print(str[j]+" ");//we can declare in a line also
	}

	}

}
