package practics;

public class If_Else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		/*
		 * if(1>2) { System.out.println("1 is greater"); } //1>2 if logic is wrong it
		 * will not print anything go to else else { System.out.println("2 is greater");
		 * }
		 */
		//To find greater number among 3 numbers
		int a=10;
		int b=20;
		int c=30;
		if(a>b & a<c)//false+true=false
		{
			System.out.println("a is smallest number :"+a);
		}
		else if(b<a & b<c)//false+true=false
		{
			System.out.println("b is smallest number :" +b);
		}
		else if(a<b & a<c)//true+true=true
		{
			System.out.println("a is smallest true condition :"+a);
		}
		else
		{
			System.out.println("c is smallest :"+c);
		}
	}

}
