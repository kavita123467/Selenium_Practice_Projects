package practics;

public class Constructor_Java {

	//global variables
	String browser;
	int text;
	
	public Constructor_Java()
	{
		//we can call constructor by object
		//parameterised constructor, default,user defined
	
	}

	public static void main(String[] args) {
		/* TODO Auto-generated method stub
		constructor are block kind of method,its look like a method but it is not a method
		constructor name should be similar to class name 
		it is a independent body we can't create it under main method
		constructor have no return type even void,we can use all modifier but mostly we use public
		not allowded public Constructor_Java
		{
		}*/
		Constructor_Java obj=new Constructor_Java();
		obj.browser="hello";
		obj.text=23;
 System.out.println(obj.browser +" "+ obj.text);
	}

}
