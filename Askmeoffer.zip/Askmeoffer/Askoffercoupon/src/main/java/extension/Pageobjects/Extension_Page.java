package extension.Pageobjects;

public class Extension_Page {

}
